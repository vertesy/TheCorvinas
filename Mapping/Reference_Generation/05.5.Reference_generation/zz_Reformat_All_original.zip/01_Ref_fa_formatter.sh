


/home/d.grun/bin/

# Transform ucsc it into gtf format
/home/d.grun/bin/ucsc2gtf.pl -in=hg19_RefSeq.tsv -out=hg19_RefSeq.gtf -m=hg19_RefSeq2gene.tsv
'maybe new line after last'
# gtf 1 line per exon, multiple isoforms for the same gene follow each other: each marked by 'transcript' in col3

#  Merge of all exons in all isofrom
/home/d.grun/bin/merge_isoforms_gtf.pl -in=hg19_RefSeq.gtf -cl=hg19_RefSeq2gene.tsv -out=hg19_RefSeq_genes.gtf
# -cl= key value: gene name >> all isoforms
# -out= no more different isoforms




#  genome reformatter : 1line/ chr
more hg19.fa |perl -ane 'chomp; $x = $_; $x = "\n".$_."\n" if /^\>/; print $x;' >jk
more jk |perl -ane '$i++; print if $i > 1;' > jk2
echo 1|perl -ane 'print "\n";' > jk2
cat jk jk2 >  hg19_reformat.fa
rm jk
rm jk2


# extract sequences from genome.fa
### genome has to be in 1 line / chr format
/home/d.grun/bin/gtf2fa.pl -in=hg19_RefSeq_genes.gtf -ref=/home/d.grun/GroupVanOudenaarden/d.grun/human_gene_models/hg19_reformat.fa > hg19_RefSeq_genes.fa

# Add the SPikeIn
cat hg19_RefSeq_genes.fa ERCC92.fa > hg19_RefSeq_genes_ERCC92.fa

'Make an index with bwa'


# Add the SPikeIn
/home/d.grun/bin/gtf2fa.pl -in=hg19_RefSeq.gtf -ref=hg19_reformat.fa > hg19_RefSeq.fa
cat hg19_RefSeq.fa ERCC92.fa > hg19_RefSeq_ERCC92.fa